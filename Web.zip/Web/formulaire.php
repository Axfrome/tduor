<!DOCTYPE html>
<html lang="fr">
    <head>
        <title> formulaire de contact</title>
        <meta charset="utf-8">
        <meta name="author" content="Atalay Tuncay">
        <meta name="description" content="essaie pour enregistré les contacts">
        <meta name="keywords" content="formulaire, contact">
        <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>
    <body>
    <form action="store.php" methode="GET">
        <table align="center">
            <tr>
                <th colspan="2" style="padding:20px;"> Page d'enregistrement</th>
            </tr>
            <tr>
                <td>Nom</td><td><input type="text" name="rname" required></td>
            </tr>
            <tr>
                <td>Email</td><td><input type="email" name="remail" required> </td>                
            </tr>
            <tr>
                <td>Sexe</td><td>Homme<input type="radio" name="rgender" value="male">Femme<input type="radio" name="rgender" value="female" required></td>
            <tr>
                <td>Avis</td><td><textarea name="rcomm" rows=10 cols=40></textarea required></td>
            </tr>
            <tr>
                <td><input type="submit" value="Envoyer le formulaire">
                </td>
            </tr>
            
        </table>
    </form>
    </body>
</html>