<?PHP
    $name = $_GET['rname'];
    $email =  $_GET['remail'];
    $gender = $_GET['rgender'];
    $comm = $_GET['rcomm'];
    $date = date('d-m-Y');

    //Connection a la database
    $servername = "localhost";
    $username = "id17449354_root";
    $password = ")))mJrGO{RW6F=PL";
    $dbname = "id17449354_essaie";
    $con = mysqli_connect($servername, $username, $password, $dbname);
    if (!$con)
        {
            die("Error :   ".mysqli_connect_error());
        }
    $sql = "INSERT INTO `testbdd`(`name`, `email`, `gender`, `avis`, `date` ) VALUES ('$name', '$email', '$gender', '$comm', '$date')"; 
    if (mysqli_query($con,$sql))
    {
        echo "Enregistrement success, merci pour l'enregistrement, vous pouvez voir les avis en cliquant plus bas  ....";
        echo '<center><a  href="avis.php"> Voir les avis</a></center>';
        
    }
    else
    {
    echo "something went wrong";
    }
    mysqli_close($con);
?>