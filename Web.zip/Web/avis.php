<?PHP
        //Connection a la database
        $servername = "localhost";
        $username = "id17449354_root";
        $password = ")))mJrGO{RW6F=PL";
        $dbname = "id17449354_essaie";
        $con = mysqli_connect($servername, $username, $password, $dbname);
        if (!$con)
            {
                die("Error :   ".mysqli_connect_error());
            }

    $sql="select * from testbdd";
    $result= mysqli_query($con, $sql) or die("bad query");

    echo "<table border='1'>";
    echo "<tr><td>nom</td><td>sexe</td><td>avis</td><td>date</td></tr>\n";

    while ($row=mysqli_fetch_assoc($result)){
        echo"<tr><td>{$row['name']}</td> <td>{$row['gender']}</td> <td>{$row['avis']}</td> <td>{$row['date']}</td></tr>\n";
    }
    echo "</table>";
    
    if (mysqli_query($con,$sql))
        {
            echo "Voilà les listes des avis avec les nom le sexe et la date";
        }
        else
        {
        echo "something went wrong";
        }
        mysqli_close($con);

?>