function getBotResponse(input) {
    if (input == "quelque chose") {
        return "HA HA HA Très drôle, tu as fais l'école du rire non ?";
    } else if (input == "qui es tu ?") {
        return "je suis un tchatbot crée à l'occasion du dernier chapitre du td sur info-fondemental";
    } else if (input == "quel est ton but ?") {
        return "je suis un robot envoyé depuis 2029 dans le passé pour trouvé sarah connor";
    } else if (input == "salut") {
        return "ça vas ?";
    } else if (input == "oui et toi ?") {
        return "ça vas ";
    } else if (input == "raconte moi une blague") {
        return "tu sais comment les belges apellent un ascenseur ? Ils appuyent sur le bouton.";
    } else return "Ecrit quelque chose"}